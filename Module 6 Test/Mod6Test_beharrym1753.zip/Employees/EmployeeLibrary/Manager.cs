﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeLibrary
{
    public class Manager : Employee
    {
        /* 
         * Date of promotion (any format)
         * 5 times base pay (use full property, not hard coded, must be multiplied by the property)
         * Email is Lastname@manager.com
         * HARD CODE USER INPUT
         */

        // Fields
        private string _empManPromotionDate;

        // Constructors
        public Manager()
        {
            EmpFirstName = "";
            EmpLastName = "";
            EmpAge = 0;
            EmpEarning = 0;
            ManagerPromotionDate = "";
        }
        public Manager(string first, string last, string phone, int age, string proDate)
        {
            EmpFirstName = first;
            EmpLastName = last;
            EmpPhoneNumber = phone;
            EmpAge = age;
            EmpEarning *= 5;    //Manager earnings reuses EmpEarning
            ManagerPromotionDate = proDate;
        }

        // Properties
        public string ManagerPromotionDate
        {
            get { return _empManPromotionDate; }
            set { _empManPromotionDate = value; }
        }

        // Methods
        public override string Email()  //Overrides and changes email tail
        {
            return EmpLastName + "@manager.com";
        }
    }
}
