﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Eventing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeLibrary
{
    public class StandardMessages
    {
        public static string DisplayMenu()
        {
            return "1. Enter employee's information.\n"+
                "2. Add managers to list(Hard Coded).\n"+
                "3. Display employee's information.\n"+
                "4. Display average age of employees.\n"+
                "5. Exit\n"+
                "--> ";
        }

        public static string PromptForFirstName()
        {
            return "Enter employee's First Name -> ";
        }
        public static string PromptForLastName()
        {
            return "Enter employee's Last Name -> ";
        }

        public static string PromptForNumber()
        {
            return "Enter employee's Phone Number -> ";
        }

        public static string PromptForAge()
        {
            return "Enter employee's Age -> ";
        }

        public static string DisplayNumberError()
        {
            return "\nNot a vaild number!\n";
        }

        public static string ListIsEmptyError()
        {
            return "Please enter an employee first.";
        }

        public static string DisplayEmployee(Employee employee)
        {
            return $"Employee's Name: {employee.EmpFullName} \nEmployee's Phone Number: {employee.EmpPhoneNumber} \nEmployee's Age: {employee.EmpAge} \nEmployee's Pay: {employee.EmpEarning} \nEmployee's Email: {employee.Email()} \n";
        }

        public static string DisplayManager(Manager manager)
        {
            return $"Manager's Name: {manager.EmpFullName} \nManager's Phone Number: {manager.EmpPhoneNumber} \nManager's Age: {manager.EmpAge} \nManager's Pay: {manager.EmpEarning} \nManager's Email: {manager.Email()} \nManager's Promotion Date: {manager.ManagerPromotionDate} \n";
        }
        
        public static string DisplayAverageAge(List<Employee> employees)
        {
            return $"Average age of employees: {employees.Average(item => item.EmpAge)}";
        }
    }
}
