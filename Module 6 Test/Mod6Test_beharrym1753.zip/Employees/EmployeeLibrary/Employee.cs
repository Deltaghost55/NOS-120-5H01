﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeLibrary
{
    public class Employee
    {
        // Fields
        private string _empFirstName;   //Split _empName into the employee's first & last name
        private string _empLastName;
        private string _empPhoneNumber;
        private double _empEarn;    //Added employee hourly earnings
        private int _empAge;

        //Constructors
        public Employee()
        {
            EmpFirstName = "";
            EmpLastName = "";
            EmpPhoneNumber = "";
            EmpEarning = 9.00;  //base pay for new employees
            EmpAge = 0;
        }

        public Employee(string firstName, string lastname, string number, double earn, int age)
        {
            EmpFirstName = firstName;
            EmpLastName = lastname;
            EmpPhoneNumber = number;
            EmpEarning = earn;
            EmpAge = age;
        }

        // Properties
        public string EmpFirstName
        { 
            get { return _empFirstName; }
            set { _empFirstName = value; }
        }

        public string EmpLastName
        {
            get { return _empLastName; }
            set { _empLastName = value; }
        }
        public string EmpFullName
        {
            get { return _empFirstName + " " + _empLastName; }
        }

        public string EmpPhoneNumber
        {
            get
            {
                return _empPhoneNumber;
            }
            set
            {
                _empPhoneNumber = value;
            }
        }

        public int EmpAge
        {
            get
            {
                return _empAge;
            }
            set
            {
                _empAge = value;
            }
        }

        public double EmpEarning
        {
            get {return _empEarn; }
            set { _empEarn = value; }
        }

        // Methods
        public virtual string Email()   //Added email method to be overridden by child classes
        {
            return EmpLastName + "@worker.com";
        }
    }
}
