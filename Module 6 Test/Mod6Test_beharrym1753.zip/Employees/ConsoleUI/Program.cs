﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmployeeLibrary;

/**
 * 5/11/2020
 * CSC 153
 * Mathias Beharry
 **/

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            // Create variable for user input and sentry for loop
            bool exit = false;

            List<Employee> employees = new List<Employee>();
            List<Manager> managers = new List<Manager>();

            // Do while loop for menu
            do
            {
                Console.Write(StandardMessages.DisplayMenu());
                // Switch to direct to proper process
                switch (Console.ReadLine())
                {
                    case "1":
                        BuildEmployees.BuildEmployeeClassObjects(employees);
                        Console.WriteLine("");
                        Console.WriteLine(StandardMessages.DisplayEmployee(employees[employees.Count - 1])); //WL in the create employee case to show the user what info they entered
                        break;
                    case "2":
                        managers.Add(new Manager("Mathias","Beharry","910-813-6373",18,"5/11/2020")); //Managers hard coded into employee list
                        managers.Add(new Manager("Thor","Finn","111-432-4687",21,"4/9/2020"));
                        Console.WriteLine("");
                        break;
                    case "3":
                        Console.WriteLine("");
                        for (int i = 0; i < employees.Count; i++)
                        {
                            Console.WriteLine(StandardMessages.DisplayEmployee(employees[i])); //For loop to display everything in the list
                        }
                        Console.WriteLine("");
                        if (managers.Count == 0)  
                        {                          
                            Console.WriteLine(StandardMessages.ListIsEmptyError());
                            Console.WriteLine("");
                            break;
                        }
                        else
                        {
                            for (int i = 0; i < managers.Count; i++)
                            {
                                Console.WriteLine(StandardMessages.DisplayManager(managers[i]));
                            }
                        }
                        Console.WriteLine("");
                        break;
                    case "4":
                        Console.WriteLine("");
                        if (employees.Count == 0)  //If statement is created just incase the user enters 3 as the first command
                        {                          //the program will tell the user to enter an employee's information first
                            Console.WriteLine(StandardMessages.ListIsEmptyError()); 
                            Console.WriteLine("");
                            break;
                        }
                        else
                        {
                            Console.WriteLine(StandardMessages.DisplayAverageAge(employees)); //Average age is calculated with the .Average() method, does not work for managers
                        }
                        Console.WriteLine("");
                        break;
                    case "5":
                        exit = true;
                        break;
                    default:
                        Console.WriteLine(StandardMessages.DisplayNumberError());
                        Console.WriteLine("");
                        break;
                }
            } while (exit == false);
        }
    }
}
